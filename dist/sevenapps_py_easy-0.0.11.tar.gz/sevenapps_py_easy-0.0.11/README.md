# SevenApps Py Easy
Proyecto creado para optimizar la programación en python, unificando mi código más utilizado.

## ¿Que Contiene?
- Plex
- MyJDownloader
- Google Services (drive, sheets)
- Selenium
- SSH

