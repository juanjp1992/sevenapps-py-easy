# SevenApps Py Easy
Proyecto creado para optimizar la programación en python, unificando mi código más utilizado.

## ¿Que Contiene?
### Google Firebase Connector
- get_data_by_path
- set_data_by_path
