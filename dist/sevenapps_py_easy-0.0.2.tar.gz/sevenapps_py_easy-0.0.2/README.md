## SevenApps Py Easy
Proyecto creado para optimizar la programación en python, unificando mi código más utilizado.